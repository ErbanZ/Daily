在python3环境下执行

使用命令 `python create_folders.py`

会在执行脚本的文件下面创建.xml文件中的树型结构文件夹